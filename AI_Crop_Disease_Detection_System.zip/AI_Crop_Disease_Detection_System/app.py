
from flask import Flask, render_template, request
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image
import os

app = Flask(__name__)

model = tf.keras.models.load_model('model/crop_disease_model.h5')

class_names = ['Healthy', 'Bacterial Spot', 'Leaf Mold', 'Early Blight']

def model_predict(img_path):
    img = image.load_img(img_path, target_size=(128, 128))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    prediction = model.predict(img_array)
    return class_names[np.argmax(prediction)]

@app.route('/', methods=['GET', 'POST'])
def home():
    prediction = None

    if request.method == 'POST':
        file = request.files['file']

        if file:
            filepath = os.path.join('static', file.filename)
            file.save(filepath)

            prediction = model_predict(filepath)

    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)


# AI-Based Crop Disease Detection System

## Overview
This project is an AI-powered crop disease detection system developed using Python and Convolutional Neural Networks (CNN).  
The model classifies crop leaf diseases from images and helps farmers identify diseases early.

## Features
- Image-based crop disease detection
- CNN deep learning model
- Data preprocessing and augmentation
- Model training and evaluation
- Flask web application for prediction
- Easy deployment

## Technologies Used
- Python
- TensorFlow / Keras
- OpenCV
- NumPy
- Flask
- Matplotlib

## Project Structure
```
AI_Crop_Disease_Detection_System/
├── app.py
├── train_model.py
├── predict.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
├── static/
├── model/
│   └── crop_disease_model.h5
└── dataset/
```

## Installation
```bash
pip install -r requirements.txt
```

## Run the Application
```bash
python app.py
```

## Dataset
Recommended dataset:
PlantVillage Dataset

## Future Enhancements
- Mobile app integration
- Real-time camera detection
- Multi-language support

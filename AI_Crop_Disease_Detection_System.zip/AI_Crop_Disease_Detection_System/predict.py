
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image

model = tf.keras.models.load_model('model/crop_disease_model.h5')

class_names = ['Healthy', 'Bacterial Spot', 'Leaf Mold', 'Early Blight']

def predict_disease(img_path):
    img = image.load_img(img_path, target_size=(128, 128))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    prediction = model.predict(img_array)
    predicted_class = class_names[np.argmax(prediction)]

    return predicted_class

if __name__ == "__main__":
    result = predict_disease("sample.jpg")
    print("Predicted Disease:", result)
